let chart;

function gerarGrafico() {
  const a = parseFloat(document.getElementById("a").value);
  const b = parseFloat(document.getElementById("b").value);
  const c = parseFloat(document.getElementById("c").value);
  const corGrafico = document.getElementById("corGrafico").value;  // Captura a cor selecionada

  if (isNaN(a) || isNaN(b) || isNaN(c)) {
    alert("Preencha todos os coeficientes corretamente!");
    return;
  }

  if (a === 0) {
    alert("O coeficiente 'a' deve ser diferente de zero!");
    return;
  }

  const xVals = [];
  const yVals = [];
  const xMin = -10, xMax = 10, step = 0.1;

  // Gerar os valores de x e y para a equação quadrática
  for (let x = xMin; x <= xMax; x += step) {
    const y = a * x * x + b * x + c;
    xVals.push(x);
    yVals.push(y);
  }

  const ctx = document.getElementById('grafico').getContext('2d');

  // Se já existir um gráfico, destrói ele antes de criar um novo
  if (chart) chart.destroy();

  // Cria o novo gráfico com a cor escolhida pelo usuário
  chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: xVals,
      datasets: [{
        label: 'f(x) = ax² + bx + c',
        data: yVals,
        borderColor: corGrafico,  // Aplica a cor do gráfico
        borderWidth: 2,
        fill: false,
        pointRadius: 0
      }]
    },
    options: {
      animation: {
        duration: 1000,
        easing: 'easeOutQuart'
      },
      responsive: false,
      scales: {
        x: {
          type: 'linear',
          min: -10,
          max: 10,
          ticks: { stepSize: 1 },
          position: 'center', 
          grid: {
            color: '#cccccc',
            lineWidth: 1
          },
          border: {
            color: '#000000', 
            width: 3
          },
          title: {
            display: true,
            text: 'x'
          }
        },
        y: {
          min: -10,
          max: 10,
          ticks: { stepSize: 1 },
          position: 'center', 
          grid: {
            color: '#cccccc',
            lineWidth: 1
          },
          border: {
            color: '#000000', 
            width: 3
          },
          title: {
            display: true,
            text: 'f(x)'
          }
        }
      },
      plugins: {
        legend: {
          display: true
        }
      }
    }
  });
}

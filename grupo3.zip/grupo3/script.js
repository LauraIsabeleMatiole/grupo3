let chart;

// Verifica se as bibliotecas estão carregadas
function verificarDependencias() {
  if (typeof Chart === 'undefined' || typeof ChartZoom === 'undefined') {
    console.error('Bibliotecas não carregadas corretamente');
    return false;
  }
  return true;
}

// Configuração padrão do zoom/pan
const zoomOptions = {
  pan: {
    enabled: true,
    mode: 'xy',
    modifierKey: null,
    threshold: 5,
    speed: 0.5
  },
  zoom: {
    wheel: {
      enabled: true,
      speed: 0.1
    },
    pinch: {
      enabled: true
    },
    mode: 'xy',
  },
  limits: {
    x: { min: -100, max: 100 },
    y: { min: -100, max: 100 }
  }
};

function gerarGrafico() {
  try {
    // Verifica dependências antes de continuar
    if (!verificarDependencias()) {
      alert('Bibliotecas necessárias não foram carregadas!');
      return;
    }

    // Obtém valores dos inputs
    const a = parseFloat(document.getElementById("a").value);
    const b = parseFloat(document.getElementById("b").value);
    const c = parseFloat(document.getElementById("c").value);
    const corGrafico = document.getElementById("corGrafico").value;
    const corPontos = document.getElementById("corPontos").value;

    // Validações
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
      alert("Preencha todos os coeficientes corretamente!");
      return;
    }

    if (a === 0) {
      alert("O coeficiente 'a' deve ser diferente de zero!");
      return;
    }

    // Cálculo dos pontos da parábola
    const xVals = [];
    const yVals = [];
    const xMin = -10, xMax = 10, step = 0.1;

    for (let x = xMin; x <= xMax; x += step) {
      const y = a * x * x + b * x + c;
      xVals.push(x);
      yVals.push(y);
    }

    // Pontos importantes (vértice, raízes, etc)
    const verticeX = -b / (2 * a);
    const verticeY = a * verticeX * verticeX + b * verticeX + c;
    const interseccaoY = { x: 0, y: c };

    let pontosPrincipais = [
      { x: verticeX, y: verticeY },
      interseccaoY
    ];

    const delta = b * b - 4 * a * c;
    if (delta >= 0) {
      const raiz1 = (-b + Math.sqrt(delta)) / (2 * a);
      const raiz2 = (-b - Math.sqrt(delta)) / (2 * a);
      pontosPrincipais.push({ x: raiz1, y: 0 }, { x: raiz2, y: 0 });
    }

    // Configuração do gráfico
    const ctx = document.getElementById('grafico').getContext('2d');
    
    if (chart) {
      chart.destroy();
    }

    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: xVals,
        datasets: [
          {
            label: `f(x) = ${a}x² ${b >= 0 ? '+' : ''}${b}x ${c >= 0 ? '+' : ''}${c}`,
            data: yVals,
            borderColor: corGrafico,
            borderWidth: 2,
            fill: false,
            pointRadius: 0
          },
          {
            type: 'scatter',
            label: 'Pontos Principais',
            data: pontosPrincipais,
            backgroundColor: corPontos,
            pointRadius: 6,
            showLine: false
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: {
          duration: 1000,
          easing: 'easeOutQuart'
        },
        scales: {
          x: {
            type: 'linear',
            position: 'center',
            grid: {
              color: '#cccccc',
              lineWidth: 1
            },
            border: {
              color: '#000000',
              width: 3
            },
            title: {
              display: true,
              text: 'x'
            }
          },
          y: {
            position: 'center',
            grid: {
              color: '#cccccc',
              lineWidth: 1
            },
            border: {
              color: '#000000',
              width: 3
            }
          }
        },
        plugins: {
          legend: {
            position: 'top',
          },
          tooltip: {
            mode: 'index',
            intersect: false
          },
          zoom: zoomOptions
        }
      }
    });

    // Adiciona botão direito para resetar zoom
    document.getElementById('grafico').oncontextmenu = (e) => {
      e.preventDefault();
      if (chart) {
        chart.resetZoom();
      }
    };

  } catch (error) {
    console.error('Erro ao gerar gráfico:', error);
    alert('Erro ao gerar gráfico. Verifique o console para detalhes.');
  }
}

// Registra a função globalmente
window.gerarGrafico = gerarGrafico;

// Registra o plugin quando a página carregar
document.addEventListener('DOMContentLoaded', () => {
  if (verificarDependencias()) {
    Chart.register(ChartZoom);
  }
});
document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const a = parseFloat(document.getElementById('a').value);
    const b = parseFloat(document.getElementById('b').value);
    const c = parseFloat(document.getElementById('c').value);

    const discriminante = b * b - 4 * a * c;
    const resultadoRaiz1 = document.getElementById('raiz1');
    const resultadoRaiz2 = document.getElementById('raiz2');
    const resultadoErro = document.getElementById('erro');

    if 
    (discriminante > 0) {
       
        const raiz1 = (-b + Math.sqrt(discriminante)) / (2 * a);
        const raiz2 = (-b - Math.sqrt(discriminante)) / (2 * a);
        resultadoRaiz1.textContent = `Raiz 1: ${raiz1.toFixed(2)}`;
        resultadoRaiz2.textContent = `Raiz 2: ${raiz2.toFixed(2)}`;
        resultadoErro.textContent = '';
    } else if (discriminante === 0) {
        
        const raiz = -b / (2 * a);
        resultadoRaiz1.textContent = `Raiz: ${raiz.toFixed(2)}`;
        resultadoRaiz2.textContent = '';
        resultadoErro.textContent = '';
    } else {
       
        resultadoRaiz1.textContent = '';
        resultadoRaiz2.textContent = '';
        resultadoErro.textContent = 'Não há raízes reais. As raízes são complexas.';
    }
});
